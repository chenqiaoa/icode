package com.qfedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlipaymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlipaymentApplication.class, args);
    }

}
