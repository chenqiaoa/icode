package com.qfedu.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@ToString
@NoArgsConstructor
@Component
@ConfigurationProperties(prefix = "alipay")
public class AlipayConfig {

    //应用的id  app_id
    @Value("${alipay.app_id}")
    public String app_id;

    //商户的私钥 merchant_private_key
    @Value("${alipay.merchant_private_key}")
    public String merchant_private_key;


    //支付宝的公钥
    @Value("${alipay.alipay_public_key}")
    public String alipay_public_key;


    //异步通知的地址
    @Value("${alipay.notify_url}")
    public String notify_url;


    //同步跳转的页面
    @Value("${alipay.return_url}")
    public String return_url;


    //签名方式
    @Value("${alipay.sign_type}")
    public String sign_type;

    //字符的编码
    @Value("${alipay.charset}")
    public String charset;

    //网关地址
    @Value("${alipay.gatewayUrl}")
    public String gatewayUrl;

    //定义一个方法返回AlipayConfig对象
    @Bean
    public AlipayConfig getAlipayConfig(){
        AlipayConfig alipayConfig = new AlipayConfig();
        alipayConfig.setApp_id(app_id);
        alipayConfig.setApp_id(merchant_private_key);
        alipayConfig.setApp_id(alipay_public_key);
        alipayConfig.setApp_id(notify_url);
        alipayConfig.setApp_id(return_url);
        alipayConfig.setApp_id(sign_type);
        alipayConfig.setApp_id(charset);
        alipayConfig.setApp_id(gatewayUrl);
        return alipayConfig;
    }
}
