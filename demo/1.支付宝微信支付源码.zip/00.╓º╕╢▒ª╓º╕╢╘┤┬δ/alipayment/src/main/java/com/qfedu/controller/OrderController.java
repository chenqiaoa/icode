package com.qfedu.controller;

import com.qfedu.pojo.Order;
import com.qfedu.service.OrderService;
import com.qfedu.utils.BaseResult;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/order")
public class OrderController {

    @Resource
    private OrderService orderService;

   /* //获取订单列表
    @ResponseBody
    @GetMapping("/list")
    public BaseResult list(){
        List<Order> list = orderService.list();
        return BaseResult.success(list);
    }*/

    //获取订单列表
    @ResponseBody
    @GetMapping("/list")
    public Map<String,Object> list(){
        List<Order> list = orderService.list();
        //return BaseResult.success(list);
        Map<String,Object> map = new HashMap<>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",list.size());
        map.put("data",list);
        return map;

    }
}
