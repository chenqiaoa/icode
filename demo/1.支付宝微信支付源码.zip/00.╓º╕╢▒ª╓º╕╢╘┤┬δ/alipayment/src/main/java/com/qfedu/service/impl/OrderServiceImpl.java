package com.qfedu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qfedu.mapper.OrderMapper;
import com.qfedu.pojo.Order;
import com.qfedu.service.OrderService;
import com.qfedu.utils.StringUtils;
import com.qfedu.utils.SysConstant;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.Date;

@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper ,Order> implements OrderService {

    @Resource
    private OrderMapper orderMapper;
    /**
     * 创建订单
     * @return
     */
    @Override
    public Order createOrder() {
        //1.生成订单编号
        Order order = new Order();
        order.setOrderNo(StringUtils.createOrderNum());
        order.setSubject("测试数据");
        order.setStatus(SysConstant.WAIT_BUYER_PAY);
        order.setTotalAmount(0.1D);
        order.setPayType("ZFB");
        order.setCreateTime(new Timestamp(new Date().getTime()));
        order.setUpdateTime(new Timestamp(new Date().getTime()));

        //调用mapper写入数据
        orderMapper.insert(order);
        return order;
    }

    //根据订单编号获取订单
    @Override
    public Order getByTradeNo(String out_trade_no) {
        //定义查询条件
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_no",out_trade_no);

        Order order = orderMapper.selectOne(queryWrapper);
        return order;
    }

    //更新订单信息
    @Override
    public void updateOrderStatus(Order order, String tradeSuccess) {
        order.setStatus(tradeSuccess);
        order.setUpdateTime(new Timestamp(new Date().getTime()));
        orderMapper.updateById(order);
    }
}
