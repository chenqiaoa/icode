package com.qfedu.service;

import com.alipay.api.AlipayApiException;

import java.util.Map;

public interface AlipayService {
    //创建支付
    String createTrade();

    boolean aliSignature(Map<String, String> params) throws AlipayApiException;

    void closeTrade(String orderNo) throws AlipayApiException;

    void refund(String orderNo) throws AlipayApiException;

    String queryRefund(String orderNo) throws AlipayApiException;
}
