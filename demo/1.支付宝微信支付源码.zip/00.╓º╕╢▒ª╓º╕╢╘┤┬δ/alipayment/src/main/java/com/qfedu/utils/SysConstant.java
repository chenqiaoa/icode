package com.qfedu.utils;

/**
 * 存放常量的接口
 */
public interface SysConstant {
    //默认的成功状态
    int STATUS_SUCCESS = 200;
    String SUCCESS_MESSAGE = "success";
    int STATUS_FAIL = 500;
    String FILE_MESSAGE = "fail";

    //订单的状态
    //代付款
    String WAIT_BUYER_PAY = "WAIT_BUYER_PAY";
    //交易成功
    String TRADE_SUCCESS = "TRADE_SUCCESS";
    //订单取消
    String CANCEL_SUCCESS = "CANCEL_SUCCESS";
    //退款成功
    String REFUD_SUCCESS = "REFUD_SUCCESS";
    //退款失败
    String REFUD_FAIL = "REFUD_FAIL";
    //订单已关闭
    String TRADE_CLOSED = "TRADE_CLOSED";

    //支付的数据格式
    String FORMAT = "json";
}
