package com.qfedu.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * mybatis-plus的配置类
 */

@MapperScan("com.qfedu.mapper")
@EnableTransactionManagement //启动事务管理器
@Configuration
public class MyBatisConfig {
}
