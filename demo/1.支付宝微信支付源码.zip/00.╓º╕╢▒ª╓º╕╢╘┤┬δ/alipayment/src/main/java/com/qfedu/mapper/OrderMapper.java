package com.qfedu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qfedu.pojo.Order;

public interface OrderMapper extends BaseMapper<Order> {
}
