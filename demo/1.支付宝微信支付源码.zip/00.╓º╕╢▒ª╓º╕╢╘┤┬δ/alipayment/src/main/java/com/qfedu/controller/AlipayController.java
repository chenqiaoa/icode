package com.qfedu.controller;

import com.alipay.api.AlipayApiException;
import com.qfedu.pojo.Order;
import com.qfedu.service.AlipayService;
import com.qfedu.service.OrderService;
import com.qfedu.utils.BaseResult;
import com.qfedu.utils.SysConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@Slf4j
@Controller
@RequestMapping("/alipay")
public class AlipayController {

    @Resource
    private AlipayService alipayService;

    @Resource
    private OrderService orderService;

    /**
     * 支付方法
     */
    @PostMapping("/trade")
    public void alipay(HttpServletResponse response) throws IOException {
        //1.创建支付
        String trade = alipayService.createTrade();
        response.setContentType("text/html;charset=utf-8");
        response.getWriter().println(trade);
    }

    //异步通知
    @PostMapping("/trade/notify")
    public String tradeNotify(@RequestParam Map<String,String> params) throws AlipayApiException {
        //System.out.println(params);
        //1.验证证书上的公钥是否一致
        boolean  signVerified = alipayService.aliSignature(params);
        if(!signVerified){
            log.info("验证失败,验证签名失败");
            return "fail";
        }

        //2.商户发送的订单号是否与返回的一致
        String out_trade_no = params.get("out_trade_no");
        Order order = orderService.getByTradeNo(out_trade_no);
        if(order == null){
            log.info("验证失败,订单不存在");
            return "fail";
        }

        //3.验证金额与发送的是否一致
        String total_amount = params.get("total_amount");
        double parseDouble = Double.parseDouble(total_amount);
        Double totalAmount = order.getTotalAmount();
        if(parseDouble != totalAmount){
            log.info("验证失败,金额不一致");
            return "fail";
        }

        //4.验证支付宝返回的状态是否一致
        String trade_status = params.get("trade_status");
        if(!SysConstant.TRADE_SUCCESS.equals(trade_status)){
            log.info("验证失败,交易状态不一致");
            return "fail";
        }

        //5.修改订单的状态
        orderService.updateOrderStatus(order,SysConstant.TRADE_SUCCESS);
        return "success";
    }

    /**
     * 关闭订单
     */
    @ResponseBody
    @PostMapping("/closeTrade/{orderNo}")
    public BaseResult closeTrade(@PathVariable String orderNo) throws AlipayApiException {
        alipayService.closeTrade(orderNo);
        return BaseResult.success("取消订单成功");
    }

    /**
     * 退款
     */
    @ResponseBody
    @PostMapping("/refund/{orderNo}")
    public BaseResult refund(@PathVariable String orderNo) throws AlipayApiException {
        alipayService.refund(orderNo);
        return BaseResult.success(SysConstant.REFUD_SUCCESS);
    }

    /**
     * 退款查询
     */
    @ResponseBody
    @GetMapping("/refundQuery/{orderNo}")
    public BaseResult queryRefund(@PathVariable String orderNo) throws AlipayApiException {
        String result = alipayService.queryRefund(orderNo);
        return BaseResult.success(result);
    }
}
