package com.qfedu.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradeCloseRequest;
import com.alipay.api.request.AlipayTradeFastpayRefundQueryRequest;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradeCloseResponse;
import com.alipay.api.response.AlipayTradeFastpayRefundQueryResponse;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.qfedu.config.AlipayConfig;
import com.qfedu.pojo.Order;
import com.qfedu.service.AlipayService;
import com.qfedu.service.OrderService;
import com.qfedu.utils.SysConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

/**
 * 阿里支付的service
 */
@Service
@Slf4j
public class AlipayServiceImpl implements AlipayService {

    @Resource
    private OrderService orderService;

    @Resource
    private AlipayConfig alipayConfig;

    //获取客户端对象
    public AlipayClient getClient(){
        //2.获取参数 (公共参数和请求参数)
        //获取支付宝的appid
        String app_id = alipayConfig.app_id;
        //获取商户的私钥
        String merchant_private_key = alipayConfig.merchant_private_key;
        //获取阿里的公钥
        String alipay_public_key = alipayConfig.alipay_public_key;
        //支付宝异步通知地址
        String notify_url = alipayConfig.notify_url;
        //同步通知地址
        String return_url = alipayConfig.return_url;
        //编码
        String charset = alipayConfig.charset;
        //签名方式
        String sign_type = alipayConfig.sign_type;
        //网关
        String gatewayUrl = alipayConfig.gatewayUrl;

        //3.获取客户端对象
        AlipayClient alipayClient = new DefaultAlipayClient(gatewayUrl,app_id,merchant_private_key, SysConstant.FORMAT,charset,alipay_public_key,sign_type);

        return alipayClient;
    }

    //创建支付
    @Override
    public String createTrade() {
        //1.创建订单
        log.info("创建订单");
        Order order = orderService.createOrder();
        AlipayClient alipayClient = getClient();
        //4.创建支付请求对象
        AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();

        //支付宝异步通知地址
        String notify_url = alipayConfig.notify_url;
        //同步通知地址
        String return_url = alipayConfig.return_url;
        //设置请求的异步通知路径
        request.setNotifyUrl(notify_url);
        //设置请求的同步通知路径
        request.setReturnUrl(return_url);
        //组装biz_content请求参数的集合
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no",order.getOrderNo());
        bizContent.put("total_amount",order.getTotalAmount());
        bizContent.put("subject",order.getSubject());
        bizContent.put("product_code","FAST_INSTANT_TRADE_PAY");

        request.setBizContent(String.valueOf(bizContent));

        //重点: 调用远程的支付宝支付接口
        AlipayTradePagePayResponse response = null;
        try {
            response  = alipayClient.pageExecute(request);
            //判断是否支付成功
            if(response.isSuccess()){
                log.info("支付成功");
            }else{
                log.info("支付失败");
            }


        } catch (AlipayApiException e) {
            e.printStackTrace();
        }

        return response.getBody();
    }

    //验证签名的方法
    @Override
    public boolean aliSignature(Map<String, String> params) throws AlipayApiException {
        boolean signVerified = AlipaySignature.rsaCheckV1(params, alipayConfig.alipay_public_key, alipayConfig.charset, alipayConfig.sign_type);
        if(!signVerified){
            return false;
        }
        return true;
    }

    @Override
    public void closeTrade(String orderNo) throws AlipayApiException {
        //1.获取alipay的客户端对象
        AlipayClient alipayClient = getClient();
        //2.创建一个关闭请求对象
        AlipayTradeCloseRequest alipayTradeCloseRequest = new AlipayTradeCloseRequest();
        //3.设置参数
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no",orderNo);
        alipayTradeCloseRequest.setBizContent(bizContent.toString());

        //4.发送请求关闭订单
        AlipayTradeCloseResponse response = alipayClient.execute(alipayTradeCloseRequest);
        if(response.isSuccess()){
            log.info("关闭订单成功");
        }else{
            log.info("关闭订单失败");
        }

        //5.更新订单
        orderService.updateOrderStatus(orderService.getByTradeNo(orderNo),SysConstant.CANCEL_SUCCESS);
    }

    @Override
    public void refund(String orderNo) throws AlipayApiException {
        //1.获取alipay的客户端对象
        AlipayClient alipayClient = getClient();
        //2.创建退款的request对象
        AlipayTradeRefundRequest  request = new AlipayTradeRefundRequest();
        Order order = orderService.getByTradeNo(orderNo);
        //3.组装业务参数
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no",orderNo);
        bizContent.put("refund_amount",order.getTotalAmount());
        request.setBizContent(bizContent.toString());
        //4.请求支付宝退款
        AlipayTradeRefundResponse response = alipayClient.execute(request);
        if(response.isSuccess()){
            log.info("退款成功,金额原路返回" + response.getBody());
        }else {
            log.info("退款失败" + response.getCode());
        }

        //5.更新订单状态
        orderService.updateOrderStatus(order,SysConstant.REFUD_SUCCESS);

    }

    /**
     * 退款查询
     * @param orderNo
     * @return
     */
    @Override
    public String queryRefund(String orderNo) throws AlipayApiException {
        //1.获取alipay的客户端对象
        AlipayClient alipayClient = getClient();
        //2.创建退款的request对象
        AlipayTradeFastpayRefundQueryRequest request = new AlipayTradeFastpayRefundQueryRequest();
        //3.组装业务参数
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no",orderNo);
        bizContent.put("out_request_no",orderNo);
        request.setBizContent(bizContent.toString());
        //4.请求查询退款信息
        AlipayTradeFastpayRefundQueryResponse response = alipayClient.execute(request);
        if(response.isSuccess()){
            log.info("查询成功" + response.getBody());
            return response.getBody();
        }else {
            log.info("查询失败" + response.getCode());
            return response.getCode();
        }
    }
}
