package com.qfedu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlipaymentApplicationTests {

    @Test
    void contextLoads() {
    }

}
