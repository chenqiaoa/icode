package com.qfedu.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.sql.Timestamp;

/**
 * 订单实体
 */
@Data
@TableName("t_order")
public class Order {
    //商品id
    @TableId(value="id",type= IdType.AUTO)
    private Long id;

    //商品标题
    private String subject;

    //订单编号
    private String orderNo;

    //订单金额(单位是分)
    private Integer totalAmount;

    //支付类型
    private String payType;

    //订单状态
    private String status;

    //二维码的url
    private String codeUrl;

    //下单时间
    private Timestamp createTime;

    //更新时间
    private Timestamp updateTime;

}
