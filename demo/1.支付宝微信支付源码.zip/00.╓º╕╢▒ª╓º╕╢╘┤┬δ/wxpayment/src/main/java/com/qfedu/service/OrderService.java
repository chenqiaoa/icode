package com.qfedu.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qfedu.pojo.Order;

public interface OrderService extends IService<Order> {
    //Order createOrder();

    Order getByTradeNo(String out_trade_no);

    void updateOrderStatus(Order order, String tradeSuccess);

    Order createWxOrder();

    void updateOrderCodeUrl(Order wxOrder, String code_url);
}
