package com.qfedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WxpaymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(WxpaymentApplication.class, args);
    }

}
