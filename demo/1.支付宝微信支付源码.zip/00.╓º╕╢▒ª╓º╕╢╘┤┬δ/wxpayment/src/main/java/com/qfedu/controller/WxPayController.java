package com.qfedu.controller;

import com.google.gson.Gson;
import com.qfedu.pojo.Order;
import com.qfedu.service.OrderService;
import com.qfedu.service.WxPayService;
import com.qfedu.utils.BaseResult;
import com.qfedu.utils.HttpUtils;
import com.qfedu.utils.SysConstant;
import com.qfedu.utils.WechatPay2ValidatorForRequest;
import com.wechat.pay.contrib.apache.httpclient.auth.Verifier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;

/**
 * 微信的支付控制器
 */
@RequestMapping("/wxpay")
@Controller
@Slf4j
public class WxPayController {

    @Resource
    private WxPayService wxPayService;

    @Resource
    private Verifier verifier;

    @Resource
    private OrderService orderService;

    /**
     * native下单
     */
    @ResponseBody
    @PostMapping("/nativePay")
    public BaseResult nativePay() throws IOException {
        //发送service请求,获取一个code_url
        Map<String,Object> map =  wxPayService.nativePay();
        return BaseResult.success(map);
    }


    /**
     * 接收微信回调的方法
     */
    @ResponseBody
    @PostMapping("/notify")
    public String nativeNotify(HttpServletRequest request , HttpServletResponse response) throws IOException, GeneralSecurityException {
        Gson gson = new Gson();
        //构建应答对象
        Map<String,String> map = new HashMap<>();
        //接收微信返回的数据
        String body = HttpUtils.readData(request);
        HashMap bodyMap = gson.fromJson(body, HashMap.class);
        log.info("支付通知完成后获取到的数据 body : "+ body);

        //进行签名验证
        WechatPay2ValidatorForRequest validator = new WechatPay2ValidatorForRequest(verifier, body, (String) bodyMap.get("id"));
        if(!validator.validate(request)){
            log.error("通知验签失败");
            response.setStatus(500);
            map.put("code","ERROR");
            map.put("message","通知验签失败");
            return gson.toJson(map);
        }
        log.info("通知验签成功");

        // 处理订单的加密数据, 根据解析出的数据,将订单的状态进行修改
        Map<String,Object> plaintMap = wxPayService.processOrder(bodyMap);
        String tradeNo = (String) plaintMap.get("out_trade_no");
        Order byTradeNo = orderService.getByTradeNo(tradeNo);
        //更新订单的状态
        orderService.updateOrderStatus(byTradeNo, SysConstant.TRADE_SUCCESS);

        response.setStatus(200);
        map.put("code","SUCCESS");
        map.put("message","成功");
        return gson.toJson(map);

    }

    /**
     * 查询订单的状态
     */
    @PostMapping("/queryOrderStatus/{orderNo}")
    @ResponseBody
    public BaseResult queryOrderStatus(@PathVariable String orderNo){
        Order order = wxPayService.queryOrderStatus(orderNo);
        if(order != null){
            return BaseResult.success("查询成功",order);
        }
        return BaseResult.fail("查询失败");
    }

    /**
     * 用户关闭订单(取消订单)
     */
    @ResponseBody
    @PostMapping("/cancelOrder/{orderNo}")
    public BaseResult cancel(@PathVariable String orderNo) throws IOException {
        log.info("取消订单开始...");
        wxPayService.cancelOrder(orderNo);
        return BaseResult.success("订单取消成功");
    }

    /**
     * 退款服务
     */
    @ResponseBody
    @PostMapping("/refund/{orderNo}")
    public BaseResult refunds(@PathVariable String orderNo) throws IOException {
        //调用service的退款服务
        log.info("开始退款");
        wxPayService.refund(orderNo);
        return BaseResult.success("退款调用成功");
    }

    /**
     * 退款通知
     */
    @ResponseBody
    @PostMapping("/refundsNotify")
    public String refundsNotify(HttpServletRequest request , HttpServletResponse response) throws IOException, GeneralSecurityException {
        //1.获取请求参数
        Gson gson = new Gson();
        Map<String,String> map = new HashMap<>();
        String data = HttpUtils.readData(request);
        HashMap dataMap = gson.fromJson(data, HashMap.class);
        //做请求签名的校验
        String requestId = (String) dataMap.get("id");
        WechatPay2ValidatorForRequest wechatPay2ValidatorForRequest = new WechatPay2ValidatorForRequest(verifier,data,requestId);
        if(!wechatPay2ValidatorForRequest.validate(request)){
            log.error("退款通知验证失败..");
            response.setStatus(500);
            map.put("code","fail");
            map.put("message","退款通知验签失败");
            return gson.toJson(map);
        }
        //验签成功
        Map<String,Object> plaintTextMap = wxPayService.processRefund(dataMap);
        //获取明文中的订单号
        String tradeNo = (String) plaintTextMap.get("out_trade_no");
        //根据订单号查询order
        Order order = orderService.getByTradeNo(tradeNo);
        //更新数据库中的订单状态
        orderService.updateOrderStatus(order,SysConstant.REFUD_SUCCESS);

        //做成功的应答
        response.setStatus(200);
        map.put("code","SUCCESS");
        map.put("message","通知成功");
        return gson.toJson(map);

    }
}
