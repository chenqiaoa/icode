package com.qfedu.utils;

/**
 * 存放常量的接口
 */
public interface SysConstant {
    //默认的成功状态
    int STATUS_SUCCESS = 200;
    String SUCCESS_MESSAGE = "success";
    int STATUS_FAIL = 500;
    String FILE_MESSAGE = "fail";

    //订单的状态
    //代付款
    String WAIT_BUYER_PAY = "WAIT_BUYER_PAY";
    //交易成功
    String TRADE_SUCCESS = "TRADE_SUCCESS";
    //订单取消
    String CANCEL_SUCCESS = "CANCEL_SUCCESS";
    //退款成功
    String REFUD_SUCCESS = "REFUD_SUCCESS";
    //退款失败
    String REFUD_FAIL = "REFUD_FAIL";
    //退款中
    String REFUND_PROCESSING = "REFUND_PROCESSING";
    //订单已关闭
    String TRADE_CLOSED = "TRADE_CLOSED";

    //支付的数据格式
    String FORMAT = "json";

    //Native下单
    String NATIVE_PAY = "/v3/pay/transactions/native";

    //订单查询
    String ORDER_QUERY_BY_NO = "/v3/pay/transactions/out-trade-no/%s";

    //关闭订单
    String CLOSE_ORDER_BY_NO = "/v3/pay/transactions/out-trade-no/%s/close";

    //申请退款
    String DOMESTIC_REFUNDS = "/v3/refund/domestic/refunds";

    //支付通知
    String NATIVE_NOTIFY = "/wxpay/notify";

    //退款通知
    String REFUND_NOTIFY = "/wxpay/refundsNotify";


}
