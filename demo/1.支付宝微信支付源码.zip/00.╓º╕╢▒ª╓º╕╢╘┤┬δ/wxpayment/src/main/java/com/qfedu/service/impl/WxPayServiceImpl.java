package com.qfedu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.gson.Gson;
import com.qfedu.config.WxPayConfig;
import com.qfedu.pojo.Order;
import com.qfedu.service.OrderService;
import com.qfedu.service.WxPayService;
import com.qfedu.utils.SysConstant;
import com.wechat.pay.contrib.apache.httpclient.util.AesUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;

/**
 * 微信支付的服务实现
 */
@Service
@Transactional
@Slf4j
public class WxPayServiceImpl implements WxPayService {

    @Resource
    private CloseableHttpClient wxPayClient;

    @Resource
    private OrderService orderService;

    @Resource
    private WxPayConfig wxPayConfig;


    /**
     * 本地支付的方法
     * @return
     */
    @Override
    public Map<String, Object> nativePay() throws IOException {
        //1.创建订单
        log.info("创建订单开始");
        Order wxOrder = orderService.createWxOrder();

        //2.调用下单API
        HttpPost httpPost = new HttpPost(wxPayConfig.getDomain().concat(SysConstant.NATIVE_PAY));
        Map<String,Object> paramMap = new HashMap<>();
        paramMap.put("appid",wxPayConfig.getAppid());
        paramMap.put("mchid",wxPayConfig.getMchId());
        paramMap.put("description",wxOrder.getSubject());
        paramMap.put("out_trade_no",wxOrder.getOrderNo());
        paramMap.put("notify_url",wxPayConfig.getNotifyDomain().concat(SysConstant.NATIVE_NOTIFY));
        //存放金额的参数
        Map<String,Object> amountMap = new HashMap<>();
        amountMap.put("total",wxOrder.getTotalAmount());
        amountMap.put("currency","CNY");
        paramMap.put("amount",amountMap);

        //参数转成json格式
        Gson gson = new Gson();
        String requestJson = gson.toJson(paramMap);
        //将json转成StringEntity对象
        StringEntity entity = new StringEntity(requestJson,"utf-8");
        entity.setContentType("application/json");
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept","application/json");

        //3.完成签名
        CloseableHttpResponse response = wxPayClient.execute(httpPost);
        //4.获取相应结果
        String bodyString = EntityUtils.toString(response.getEntity()); //请求后得到的响应体
        int statusCode = response.getStatusLine().getStatusCode();
        //如果处理成功(带响应体的)
        if(statusCode == 200){
            log.info("请求成功 : "+bodyString);
        }else if(statusCode == 204){ //处理成功但是不带 body
            log.info("处理成功 204");
        }else{
            log.info("native 下单失败 响应码为 "+ statusCode + " 返回的结果 "+ bodyString);
        }
        //5.更新订单中的code_url信息
        //把body中的信息转成map ,直接返回
        Map<String , String> resultMap = gson.fromJson(bodyString,HashMap.class);
        String code_url = resultMap.get("code_url");
        Map<String , Object> map = new HashMap<>();
        map.put("codeUrl",code_url);
        map.put("orderNo",wxOrder.getOrderNo());

        //@TODO
        //更新订单中的codeurl信息
        orderService.updateOrderCodeUrl(wxOrder,code_url);

        return map;
    }

    /**
     * 解密数据
     * @param bodyMap
     * @return
     */
    @Override
    public Map<String, Object> processOrder(HashMap bodyMap) throws GeneralSecurityException {
        //1.密文机密操作
        String plainText = decryptFromResouce(bodyMap);
        //2.转成map格式
        Gson gson = new Gson();
        HashMap plainTextMap = gson.fromJson(plainText, HashMap.class);
        return plainTextMap;
    }



    /**
     * 因为加密方式AES方式, 解密也需要AES方式
     * @param bodyMap
     * @return
     */
    private String decryptFromResouce(HashMap bodyMap) throws GeneralSecurityException {
        //获取通知中的resouce这部分加密数据
        Map<String,String> resourceMap = (Map<String, String>) bodyMap.get("resource");
        //获取密文
        String ciphertext =  resourceMap.get("ciphertext");
        // 随机串获取
        String nonce = resourceMap.get("nonce");
        //获取附加数据
        String associatedData = resourceMap.get("associated_data");

        System.out.println("ciphertext = " + ciphertext);

        //使用APIV3秘钥进行解密
        AesUtil aesUtil = new AesUtil(wxPayConfig.getApiV3Key().getBytes(StandardCharsets.UTF_8));
        //使用该工具进行解密
        String plainText =  aesUtil.decryptToString(associatedData.getBytes(StandardCharsets.UTF_8), nonce.getBytes(StandardCharsets.UTF_8), ciphertext);
        return  plainText;

    }


    @Override
    public Order queryOrderStatus(String orderNo) {
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        Order order = orderService.getByTradeNo(orderNo);
        return order;
    }

    /**
     * 取消订单
     * @param orderNo
     */
    @Override
    public void cancelOrder(String orderNo) throws IOException {
        log.info("service 取消订单开始");
        //创建远程的请求对象
        String url = String.format(SysConstant.CLOSE_ORDER_BY_NO,orderNo);
        url = wxPayConfig.getDomain().concat(url);
        HttpPost httpPost = new HttpPost(url);

        //组装json的请求体
        Gson gson = new Gson();
        Map<String,String> paramsMap = new HashMap<>();
        paramsMap.put("mchid",wxPayConfig.getMchId());
        String jsonParams = gson.toJson(paramsMap);

        //请求参数设置到请求对象中
        StringEntity entity = new StringEntity(jsonParams,"utf-8");
        entity.setContentType("application/json");
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept","application/json");
        //完成签名并执行
        CloseableHttpResponse response = wxPayClient.execute(httpPost);

        try {
            //获取相应信息
            int statusCode = response.getStatusLine().getStatusCode();
            if(statusCode == 200){
                log.info("取消成功, 返回状态码200");
            }else if(statusCode == 204){
                log.info("取消成功, 没有body返回体 ,状态码 204");
            }else{
                log.info("取消订单失败 , 状态码为 "+ statusCode);
                throw new IOException("请求失败 ,取消订单异常");
            }
        } finally {
            response.close();
        }

        //更新商户的订单状态
        Order order = orderService.getByTradeNo(orderNo);
        orderService.updateOrderStatus(order,SysConstant.CANCEL_SUCCESS);

    }

    @Override
    public void refund(String orderNo) throws IOException {
        //根据订单id查询订单信息
        Order order = orderService.getByTradeNo(orderNo);
        //准备请求的url
        String url = wxPayConfig.getDomain().concat(SysConstant.DOMESTIC_REFUNDS);
        HttpPost httpPost = new HttpPost(url);
        //封装请求参数
        Gson gson = new Gson();
        Map<String ,Object> paramMap = new HashMap<>();
        paramMap.put("out_trade_no",orderNo); //订单的编号
        paramMap.put("out_refund_no",orderNo); //退款的编号
        //设置通知地址,退款后回调通知
        paramMap.put("notify_url",wxPayConfig.getNotifyDomain().concat(SysConstant.REFUND_NOTIFY));
        //设置金额的参数
        Map amountMap = new HashMap();
        amountMap.put("refund",order.getTotalAmount()); //设置退款金额
        amountMap.put("total",order.getTotalAmount()); //原订单金额
        amountMap.put("currency","CNY"); //退款的币种
        paramMap.put("amount",amountMap);

        //将参数转成json
        String jsonParams = gson.toJson(paramMap);

        //将参数再次封装到StringEntity
        StringEntity entity = new StringEntity(jsonParams,"utf-8");
        entity.setContentType("application/json");
        httpPost.setEntity(entity);
        httpPost.setHeader("Accept","application/json");

        //发起退款请求,对请求的内容进行签名验证
        CloseableHttpResponse response = wxPayClient.execute(httpPost);

        //解析相应
        try {
            HttpEntity httpEntity = response.getEntity();
            String bodyString = EntityUtils.toString(httpEntity);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == 200){
                log.info("退款申请成功...等待退款结果"+ bodyString);
            }else if (statusCode == 204){
                log.info("退款申请成功");
            }else{
                log.info("退款申请失败");
                throw new RuntimeException("退款异常 , 响应码是"+statusCode + " , 相应内容是 "+bodyString );
            }
        } finally {
                response.close();
        }

        //更新订单状态
        orderService.updateOrderStatus(order,SysConstant.REFUND_PROCESSING);
    }

    /**
     * 解密数据
     * @param dataMap
     * @return
     */
    @Override
    public Map<String, Object> processRefund(HashMap dataMap) throws GeneralSecurityException {
        //1.转换相应中的密文
        String decryptText = decryptFromResouce(dataMap);
        //2.把转后的明文数据转成map
        Gson gson = new Gson();
        HashMap plaintTextmap = gson.fromJson(decryptText, HashMap.class);
        return plaintTextmap;
    }
}
