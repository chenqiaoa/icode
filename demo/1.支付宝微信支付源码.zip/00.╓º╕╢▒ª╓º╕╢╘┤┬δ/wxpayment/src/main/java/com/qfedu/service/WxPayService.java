package com.qfedu.service;

import com.qfedu.pojo.Order;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;

public interface WxPayService {
    /**
     * native支付
     * @return
     */
    Map<String, Object> nativePay() throws IOException;

    /**
     * 加密数据解密的方法
     * @param bodyMap
     * @return
     */
    Map<String, Object> processOrder(HashMap bodyMap) throws GeneralSecurityException;

    Order queryOrderStatus(String orderNo);

    void cancelOrder(String orderNo) throws IOException;

    void refund(String orderNo) throws IOException;

    Map<String, Object> processRefund(HashMap dataMap) throws GeneralSecurityException;
}
