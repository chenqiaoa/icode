package com.itsoku.lesson004.utils;

import java.util.UUID;

/**
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人 <br>
 * <b>time</b>：2024/3/26 22:24 <br>
 * <b>author</b>：ready likun_557@163.com
 */
public class IdUtils {

    public static String generateId() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
