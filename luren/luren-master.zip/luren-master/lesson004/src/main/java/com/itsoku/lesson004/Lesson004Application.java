package com.itsoku.lesson004;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 分片上传
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人 <br>
 * <b>time</b>：2024/3/26 21:01 <br>
 * <b>author</b>：ready likun_557@163.com
 */
@SpringBootApplication
@MapperScan(basePackages = "com.itsoku.lesson004.mapper")
public class Lesson004Application {

    public static void main(String[] args) {
        SpringApplication.run(Lesson004Application.class, args);
    }

}
