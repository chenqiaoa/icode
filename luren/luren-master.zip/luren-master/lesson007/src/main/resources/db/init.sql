-- 创建一张测试表
create table if not exists t_lesson007(
    id varchar(50) primary key,
    data varchar(100)
);
