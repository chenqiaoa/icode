package com.itsoku.lesson012.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itsoku.lesson012.po.AccountPO;
import com.itsoku.lesson012.po.IdempotentPO;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

/**
 * <b>description</b>： Java高并发、微服务、性能优化实战案例100讲，视频号：程序员路人 <br>
 * <b>time</b>：2024/4/4 23:13 <br>
 * <b>author</b>：ready likun_557@163.com
 */
public interface IdempotentMapper extends BaseMapper<IdempotentPO> {
}
